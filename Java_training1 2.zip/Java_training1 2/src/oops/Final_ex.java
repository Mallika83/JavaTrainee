package oops;

public class Final_ex {

	final String Nric="Abc2098"; //final variables we cannot change during program execution
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Final_ex f=new Final_ex();
System.out.println("The NRIC num is :"+f.Nric);
//f.Nric="yth098"; // We cannot do this
	}

}
