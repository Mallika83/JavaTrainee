package oops;

public class default_constructor {
int age;
String name;
float salary;
boolean yes;

void display()
{
	System.out.println(age);
	System.out.println(name);
	System.out.println(salary);
	System.out.println(yes);
	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
default_constructor d=new default_constructor();
d.display();
	}

}
