package oops;

public class Ex_access_modifiers extends Package_ex {

	public static void main(String[] args) {
		Ex_access_modifiers access=new Ex_access_modifiers();
System.out.println(access.a);
	}

}
