package oops;

public class Package_ex {
 protected  int a=10;
	public double calc(double a,double b,double c)
	{
		return ((a*b)/c);
	}

	public static void main(String[] args) {
		
	}

}
