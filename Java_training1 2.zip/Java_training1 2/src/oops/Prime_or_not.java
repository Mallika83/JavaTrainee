package oops;
import java.util.*;
public class Prime_or_not {

	public static void main(String[] args) {
		int number,i;
		boolean flag=false;
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the number");
		number=s.nextInt();
		if(number==0 || number==1)
		{
			System.out.println("The number is neither prime nor composite");
		}
		if(number==2)
			System.out.println("The number is prime");
		for(i=2;i<number/2;i++)
		{
			if(number%i==0)
			{
			flag=true;
			break;
			}
				
		}
		if(flag)
			System.out.println("The number is  not prime");
		else
			System.out.println("The number is prime");
		
	}

}
