package looping_stmts;

public class nested_loop_ex {

	public static void main(String[] args) {
		
int i,j;
for(i=0;i<5;i++)
{
	//System.out.print(i);
	for(j=0;j<5;j++)
	{
		
		System.out.print(" "+j);
	}
	System.out.println();
}


	}

}
