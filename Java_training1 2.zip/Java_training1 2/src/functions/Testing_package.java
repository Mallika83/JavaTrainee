package functions;
import oops.*;
public class Testing_package extends Package_ex {

	public static void main(String[] args) {
		
		Package_ex p=new Package_ex();
		//System.out.println(p.a);
		System.out.println(p.calc(12.9,89.0,78.1));
	}

}
