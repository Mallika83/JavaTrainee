
public class demo {

	public demo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int course_id;
		String course_name;
		course_id=1001;
		course_name="Java Fuul Stack";
		System.out.println("course id is " + course_id);
		System.out.println("Course name is " + course_name);

	}

}
