package Multi_Threading;

public class Runtime_ex  {
 public static void main(String[] args) throws Exception
{
	Runtime.getRuntime().exec("textedit");
}
}
