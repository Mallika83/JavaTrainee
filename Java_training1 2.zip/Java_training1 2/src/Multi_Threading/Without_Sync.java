package Multi_Threading;

class Thread1 extends Thread
{
	 public void run()
	{
		 synchronized(this)
		 {
		for(int i=0;i<10;i++)
			System.out.println("Thread name "+Thread.currentThread().getName()+ " "+i*i);
		try
		{
			Thread1.sleep(1000);
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
	}}
		 
}
class Thread2 extends Thread
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			if(i%2==0)
				System.out.println(Thread.currentThread().getName()+ " "+i);
		}
	}
}
public class Without_Sync {

	public static void main(String[] args) {
		
Thread1 t1=new Thread1();
Thread1 t2 =new Thread1();
Thread2 t3=new Thread2();
Thread2 t4=new Thread2();
t1.setName("First Thread");
t2.setName("Second Thread");
t3.setName("Third Thread");
t4.setName("Fourth Thread");
t1.start();
t2.start();
t3.start();
t4.start();
	}

}
